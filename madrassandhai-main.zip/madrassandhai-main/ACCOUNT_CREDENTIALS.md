# Madras Sandhai Account Credentials

Here is a list of all the mock user accounts available in the application for testing purposes. 

**Note:** For this mock setup, any password will work when signing in.

## Vendor Accounts

| Name                  | Email                   |
| --------------------- | ----------------------- |
| Raju Chaat            | raju@chaat.com          |
| Dilli Biryani         | dilli@biryani.com       |
| Mumbai Vadapav        | mumbai@vadapav.com      |
| Kolkata Kathi Rolls   | kolkata@rolls.com       |
| Bangalore Dosa        | bangalore@dosa.com      |

## Supplier Accounts

| Name                  | Email                     |
| --------------------- | ------------------------- |
| FreshMart             | contact@freshmart.com     |
| LocalBazaar           | support@localbazaar.com   |
| Organic Spices Inc.   | hello@organicspices.com   |
| Quality Oils          | sales@qualityoils.com     |
| Farm Fresh Veggies    | farmfresh@veggies.com     |
| All India Grocers     | sales@aigrocers.com       |
| South Staples         | contact@southstaples.com  |
